import sys
import requests
import base64

# Configuration
PROJECT_KEY = "Qvi3o2sZUDwakk62XNrnfcK4H6OfXvVw"
URL = f"https://chunks.memfault.com/api/v0/chunks/{PROJECT_KEY}"

def upload_chunk(chunk_str):
    # Clean up the chunk string
    chunk_str = chunk_str.strip()
    if chunk_str.startswith("MC:"):
        chunk_str = chunk_str[3:]
    if chunk_str.endswith(":"):
        chunk_str = chunk_str[:-1]
        
    print(f"Uploading chunk: {chunk_str[:20]}...")
    
    try:
        # Decode base64
        data = base64.b64decode(chunk_str)
        
        # Upload
        headers = {"Content-Type": "application/octet-stream"}
        response = requests.post(URL, data=data, headers=headers)
        
        if response.status_code == 202:
            print("✅ SUCCESS! Chunk uploaded successfully.")
            print("Go check your dashboard now!")
        else:
            print(f"❌ FAILED. Status: {response.status_code}")
            print(f"Response: {response.text}")
            
    except Exception as e:
        print(f"❌ ERROR: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python upload_chunk.py <MC_STRING>")
        print("Example: python upload_chunk.py MC:SFECpwIBAwEKZG1haW4JZTEuMC4w...")
    else:
        upload_chunk(sys.argv[1])
