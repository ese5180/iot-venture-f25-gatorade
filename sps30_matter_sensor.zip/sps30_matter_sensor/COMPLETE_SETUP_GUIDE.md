# Complete Memfault Setup Guide - Step by Step

## ✅ **Step 1: Build the Firmware**

### In VS Code with nRF Connect Extension:

1. **Open nRF Connect sidebar** (left panel, nRF icon)

2. **Add/Edit Build Configuration:**
   - Click "Add Build Configuration" or edit existing
   - Board: `xiao_nrf54l15/nrf54l15/cpuapp`
   - ✅ **Check "Use sysbuild"** (CRITICAL!)
   - Click "Build Configuration"

3. **Wait for build** to complete (may take 2-3 minutes first time)

4. **Look for success message:**
   ```
   [100%] Built target zephyr_final
   ```

### Or via Command Line:

```bash
cd c:\Users\geniu\sps30_matter_sensor
west build -b xiao_nrf54l15/nrf54l15/cpuapp --sysbuild --pristine
```

---

## ✅ **Step 2: Flash the Firmware**

### In VS Code:

1. **Connect your XIAO board** via USB

2. **Click "Flash"** button (lightning bolt icon) in nRF Connect panel

3. **Wait for flashing** to complete

### Or via Command Line:

```bash
west flash
```

---

## ✅ **Step 3: Verify It's Running**

1. **Open Serial Monitor:**
   - In VS Code: Terminal → New Terminal
   - Or use PuTTY/Tera Term at 115200 baud

2. **You should see:**
   ```
   *** Booting MCUboot v2.1.0 ***
   *** Using nRF Connect SDK v3.0.2 ***
   I: Starting bootloader
   I: Primary image: magic=good, swap_type=0x1, copy_done=0x3, image_ok=0x3
   I: Scratch: magic=unset, swap_type=0x1, copy_done=0x3, image_ok=0x3
   I: Boot source: primary slot
   I: Image index: 0, Swap type: none
   I: Bootloader chainload address offset: 0x28000
   
   === SPS30 Sensor with Memfault ===
   Firmware Version: 1.0.0
   Device ID: sps30_sensor_001
   
   Bluetooth initialized
   Advertising successfully started
   BME680 OK
   UART OK
   
   Reading sensors...
   
   [0] Temp: 22.39°C | Hum: 28.19% | PM2.5: --
   ```

3. **Key things to verify:**
   - ✅ "Advertising successfully started" - Bluetooth is working
   - ✅ "BME680 OK" - Temperature sensor working
   - ✅ Temperature and humidity readings

---

## ✅ **Step 4: Install nRF Connect Device Manager App**

### On Your Phone:

**iOS:**
- Open App Store
- Search "nRF Connect Device Manager"
- Install (by Nordic Semiconductor)

**Android:**
- Open Google Play Store
- Search "nRF Connect Device Manager"
- Install (by Nordic Semiconductor)

---

## ✅ **Step 5: Connect via Bluetooth**

1. **Open nRF Connect Device Manager app**

2. **Grant Bluetooth permissions** if asked

3. **Tap "Scan"** or pull down to refresh

4. **Look for "SPS30_Sensor"** in the device list

5. **Tap on "SPS30_Sensor"** to connect

6. **Wait for connection** (should take 2-3 seconds)

7. **You should see:**
   - Device name: SPS30_Sensor
   - Firmware version: 1.0.0
   - Device ID: sps30_sensor_001
   - Various options (Device Info, Firmware Update, etc.)

---

## ✅ **Step 6: Access nRF Cloud Dashboard**

1. **Open browser** and go to: [nrfcloud.com](https://nrfcloud.com)

2. **Log in** with your account

3. **Click "Devices"** in left sidebar

4. **Find your device:** `sps30_sensor_001`

5. **Click on the device** to see:
   - **Overview:** Status, firmware version, last seen
   - **Metrics:** Built-in metrics (uptime, reboot count)
   - **Issues:** Crash reports (if any)
   - **Firmware:** OTA update management

---

## ✅ **Step 7: Test Crash Reporting (Optional)**

1. **Connect to device** via serial monitor

2. **Press Enter** to get shell prompt

3. **Type:** `mflt test assert`

4. **Press Enter** - device will crash and reboot

5. **Reconnect via Bluetooth** using the app

6. **Data will sync** to cloud

7. **Check nRF Cloud** → Devices → Your Device → Issues
   - You should see the crash report with stack trace

---

## ✅ **Step 8: Test OTA Update (Optional)**

### Create New Firmware Version:

1. **Edit `prj.conf`** and change version:
   ```conf
   CONFIG_MEMFAULT_NCS_FW_VERSION="1.0.1"
   CONFIG_BT_DIS_FW_REV_STR="1.0.1"
   CONFIG_MCUBOOT_IMGTOOL_SIGN_VERSION="1.0.1"
   ```

2. **Rebuild** with sysbuild

3. **Find the update file:**
   - Location: `build/sps30_matter_sensor/zephyr/app_update.bin`

### Upload to nRF Cloud:

4. **Go to nRF Cloud** → Firmware

5. **Click "Upload Firmware"**

6. **Select:** `app_update.bin`

7. **Fill in:**
   - Version: 1.0.1
   - Description: "Test OTA update"

8. **Click "Upload"**

### Deploy Update:

9. **Create a release:**
   - Click "Create Release"
   - Select version 1.0.1
   - Click "Create"

10. **Activate release:**
    - Click "Activate"
    - Select your device or "All devices"

### Install on Device:

11. **Open nRF Device Manager app**

12. **Connect to device**

13. **Tap "Firmware Update"**

14. **Tap "Check for updates"**

15. **Tap "Download and Install"**

16. **Wait for update** (1-2 minutes)

17. **Device will reboot** with new version

18. **Verify:** Serial monitor should show "Firmware Version: 1.0.1"

---

## 📊 **What Data is Sent to Memfault?**

Even without custom metrics, Memfault collects:

✅ **Device Info:**
- Firmware version (1.0.0)
- Device ID (sps30_sensor_001)
- Hardware revision (xiao_nrf54l15)

✅ **Built-in Metrics:**
- Uptime (seconds)
- Reboot count
- Unexpected reboot count

✅ **Crash Data:**
- Stack traces
- Register dumps
- Coredumps

✅ **Events:**
- Bluetooth connections
- Reboots
- Errors

---

## 🔧 **Troubleshooting**

### "Advertising successfully started" but can't find device in app:

- Make sure Bluetooth is enabled on phone
- Make sure location permission is granted (Android)
- Try restarting the app
- Try moving phone closer to device

### Can't connect to device:

- Make sure device is still advertising (check serial output)
- Try forgetting device in phone Bluetooth settings
- Restart both device and phone

### Device not showing in nRF Cloud:

- Make sure you connected via the app at least once
- Data only syncs when connected via Bluetooth
- Check "Last Seen" timestamp - may take a few minutes

### Build fails:

- Make sure "Use sysbuild" is checked
- Try "Pristine Build"
- Check that project key is set in `prj.conf`

---

## ✅ **Success Checklist**

- [ ] Firmware builds successfully with sysbuild
- [ ] Device boots and shows Memfault version
- [ ] Bluetooth advertising starts
- [ ] BME680 shows temperature and humidity
- [ ] Can find "SPS30_Sensor" in nRF Device Manager app
- [ ] Can connect via app
- [ ] Device appears in nRF Cloud dashboard
- [ ] Can see firmware version in cloud

---

## 📱 **Quick Reference**

**Serial Monitor Settings:**
- Baud rate: 115200
- Data bits: 8
- Parity: None
- Stop bits: 1

**Bluetooth Device Name:** SPS30_Sensor

**Device ID:** sps30_sensor_001

**Firmware Version:** 1.0.0

**nRF Cloud:** [nrfcloud.com](https://nrfcloud.com)

---

That's it! You now have full Memfault fleet management with OTA updates and crash reporting! 🚀
