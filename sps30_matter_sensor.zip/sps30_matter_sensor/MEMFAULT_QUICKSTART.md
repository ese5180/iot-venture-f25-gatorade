# Quick Start - Memfault Integration

## 1. Get Project Key
- Go to [nrfcloud.com](https://nrfcloud.com)
- Settings → General → Copy Project Key
- Update in `prj.conf`: `CONFIG_MEMFAULT_NCS_PROJECT_KEY="YOUR_KEY"`

## 2. Build & Flash
```bash
west build -b xiao_nrf54l15/nrf54l15/cpuapp --sysbuild
west flash
```

## 3. Connect
- Install nRF Connect Device Manager app
- Scan for "SPS30_Sensor"
- Connect

## 4. View Data
- Go to nRF Cloud dashboard
- See metrics: temperature, humidity, PM2.5
- View traces and crashes

## Features Demonstrated

✅ **OTA Updates** - Version 1.0.0, upgradeable via Bluetooth  
✅ **Core Dump** - Crash reporting (test with `mflt test assert`)  
✅ **Custom Metrics** - Temperature, humidity, PM2.5 forwarded to cloud  

## Shell Commands
```
mflt get_device_info    # Device info
mflt test assert        # Trigger crash
mflt get_core           # Show metrics
```

## Files Modified
- `prj.conf` - Added Memfault config
- `sysbuild.conf` - Enabled MCUBoot
- `main.c` - Integrated Memfault SDK

See **MEMFAULT_GUIDE.md** for full documentation.
