# Complete Wiring Diagram for Seeed Studio XIAO nRF54L15

## Overview
This document provides the complete wiring instructions for connecting both the BME680 and SPS30 sensors to your Seeed Studio XIAO nRF54L15 board.

---

## Pin Mapping Reference

### XIAO nRF54L15 Pinout
```
         USB
    ┌────────────┐
D0  │ P1.4    5V │  5V Output
D1  │ P1.5   GND │  Ground
D2  │ P1.6  3.3V │  3.3V Output
D3  │ P1.7   GND │  Ground
D4  │ P1.8   SCL │  I2C Clock (P1.11)
D5  │ P1.9   SDA │  I2C Data (P1.10)
    └────────────┘
```

---

## Sensor 1: BME680 (Temperature & Humidity)

### Connection Table

| BME680 Pin | Function | Connect To XIAO | Wire Color Suggestion |
|------------|----------|-----------------|----------------------|
| **VCC**    | Power    | **3.3V**       | Red                  |
| **GND**    | Ground   | **GND**        | Black                |
| **SCL**    | I2C Clock| **D4** (P1.8)  | Yellow               |
| **SDA**    | I2C Data | **D5** (P1.9)  | Green                |

### Notes
- ✅ BME680 uses **3.3V** power
- ✅ I2C address: **0x77** (default for most modules)
- ✅ No pull-up resistors needed (usually built into module)

---

## Sensor 2: SPS30 (Particulate Matter)

### Connection Table

| SPS30 Pin | Function | Description | Connect To XIAO | Wire Color Suggestion |
|-----------|----------|-------------|-----------------|----------------------|
| **Pin 1** | VDD      | Power Supply| **5V**         | Red                  |
| **Pin 2** | RX       | Receive Data| **D0** (P1.4)  | Orange               |
| **Pin 3** | TX       | Transmit Data| **D1** (P1.5) | Yellow               |
| **Pin 4** | SEL      | Interface Select | **Leave FLOATING** or GND | (None) |
| **Pin 5** | GND      | Ground      | **GND**        | Black                |

### Critical Notes

⚠️ **POWER REQUIREMENTS:**
- The SPS30 **MUST** be powered with **5V**, not 3.3V
- Current draw: 60mA average, 80mA peak
- The XIAO's 5V pin can provide this when USB-powered
- When powered correctly, you should **hear/feel the fan spinning**

⚠️ **UART WIRING (TX/RX CROSSOVER):**
- **SPS30 TX (Pin 3)** → **XIAO RX (D1)**
- **SPS30 RX (Pin 2)** → **XIAO TX (D0)**
- This is a crossover connection - TX goes to RX and vice versa!

⚠️ **INTERFACE SELECT (Pin 4):**
- For UART mode: **Leave floating** (not connected) OR connect to GND
- For I2C mode: Connect to VDD (we're NOT using this)
- **Recommended: Leave Pin 4 completely disconnected**

⚠️ **UART SETTINGS:**
- Baud rate: 115200
- Data bits: 8
- Parity: None
- Stop bits: 1

---

## Complete Wiring Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    XIAO nRF54L15 Board                          │
│                                                                 │
│  D0 (TX) ────────────────────────────────────┐                 │
│  D1 (RX) ──────────────────────────┐         │                 │
│  D4 (SCL) ──────────┐              │         │                 │
│  D5 (SDA) ────┐     │              │         │                 │
│  3.3V ──┐     │     │              │         │                 │
│  5V ────│─────│─────│──────────────│─────────│────┐            │
│  GND ───│─────│─────│──────────────│─────────│────│───┐        │
└─────────┼─────┼─────┼──────────────┼─────────┼────┼───┼────────┘
          │     │     │              │         │    │   │
          │     │     │              │         │    │   │
    ┌─────┴─────┴─────┴────┐   ┌─────┴─────────┴────┴───┴────┐
    │     BME680 Sensor     │   │      SPS30 Sensor           │
    │                       │   │                             │
    │  VCC ← 3.3V           │   │  Pin 1 (VDD) ← 5V          │
    │  GND ← GND            │   │  Pin 2 (RX)  ← TX (D0)     │
    │  SCL ← D4             │   │  Pin 3 (TX)  → RX (D1)     │
    │  SDA ← D5             │   │  Pin 4 (SEL) ← FLOATING    │
    │                       │   │  Pin 5 (GND) ← GND         │
    └───────────────────────┘   └─────────────────────────────┘
```

---

## Physical Connection Steps

### Step 1: Power Off
- Disconnect the XIAO board from USB
- Ensure no power is applied during wiring

### Step 2: Connect BME680
1. Connect BME680 **VCC** to XIAO **3.3V**
2. Connect BME680 **GND** to XIAO **GND**
3. Connect BME680 **SCL** to XIAO **D4**
4. Connect BME680 **SDA** to XIAO **D5**

### Step 3: Connect SPS30
1. Connect SPS30 **Pin 1 (VDD)** to XIAO **5V**
2. Connect SPS30 **Pin 5 (GND)** to XIAO **GND**
3. Connect SPS30 **Pin 2 (RX)** to XIAO **D0 (TX)**
4. Connect SPS30 **Pin 3 (TX)** to XIAO **D1 (RX)**
5. **Leave SPS30 Pin 4 (SEL) unconnected** (floating)

### Step 4: Verify Connections
Double-check all connections against the tables above:
- [ ] BME680 powered from 3.3V
- [ ] SPS30 powered from 5V
- [ ] All grounds connected
- [ ] I2C wires (D4/D5) to BME680
- [ ] UART wires crossed (D0→RX, D1→TX)
- [ ] SPS30 Pin 4 floating

### Step 5: Power On Test
1. Connect XIAO to USB
2. **Listen for SPS30 fan** - you should hear it spinning
3. If fan doesn't spin, check 5V power connection

---

## Troubleshooting

### BME680 Not Responding
- Check I2C address (should be 0x77)
- Verify 3.3V power
- Check SCL/SDA connections
- Try swapping SCL and SDA if still not working

### SPS30 Fan Not Spinning
- **Most common issue**: Not getting 5V power
- Verify 5V pin connection
- Check GND connection
- Try different USB cable/port (some provide more power)

### SPS30 No UART Data
- Verify TX/RX crossover (SPS30 TX → Board RX)
- Check Pin 4 is floating (not connected to anything)
- Ensure fan is spinning (indicates power is good)
- Verify baud rate is 115200

### SPS30 Reads Zero
- Wait 30-60 seconds for sensor warm-up
- Sensor may be in very clean air
- Try testing near dust source or blow gently near sensor
- Verify measurement mode was started

---

## Final Checklist

Before running your code, verify:

- [ ] BME680 VCC → 3.3V
- [ ] BME680 GND → GND
- [ ] BME680 SCL → D4
- [ ] BME680 SDA → D5
- [ ] SPS30 Pin 1 → 5V
- [ ] SPS30 Pin 2 → D0 (TX)
- [ ] SPS30 Pin 3 → D1 (RX)
- [ ] SPS30 Pin 4 → FLOATING (not connected)
- [ ] SPS30 Pin 5 → GND
- [ ] SPS30 fan spinning when powered
- [ ] Code compiled and flashed successfully

---

## Expected Output

When everything is working correctly, you should see:

```
=== BME680 + SPS30 Sensor Reader ===

BME680 initialized
Sending SPS30 wake-up...
Sending SPS30 start measurement...
SPS30 initialized
Starting measurements...

[Frame 47 bytes: 7E 00 03 00 28 ...] [PM1.0=2.34 PM2.5=3.45 PM4.0=4.56 PM10=5.67] Temp: 23.45°C | Hum: 45.67% | PM2.5: 3.45 µg/m³
```

---

## Power Consumption

| Component | Voltage | Current | Power |
|-----------|---------|---------|-------|
| XIAO nRF54L15 | 3.3V | ~10mA | ~33mW |
| BME680 | 3.3V | ~3mA | ~10mW |
| SPS30 | 5V | 60-80mA | 300-400mW |
| **Total** | - | ~75-95mA | ~350-450mW |

USB can typically provide 500mA, so this setup is well within limits.

---

## Additional Resources

- [XIAO nRF54L15 Wiki](https://wiki.seeedstudio.com/xiao_nrf54l15/)
- [BME680 Datasheet](https://www.bosch-sensortec.com/products/environmental-sensors/gas-sensors/bme680/)
- [SPS30 Datasheet](https://sensirion.com/products/catalog/SPS30)
- [SPS30 UART Protocol](https://github.com/Sensirion/embedded-uart-sps30)

---

Good luck with your sensor project! 🎉
