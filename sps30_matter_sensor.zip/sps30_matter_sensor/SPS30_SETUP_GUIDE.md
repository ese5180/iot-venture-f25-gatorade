# SPS30 Particulate Matter Sensor - Complete Setup Guide

## Overview
This guide explains how to integrate the Sensirion SPS30 particulate matter sensor with your XIAO nRF54L15 board using UART communication and the SHDLC protocol.

---

## Hardware Setup

### Pin Connections

| SPS30 Pin | Function | Description | Connect To |
|-----------|----------|-------------|------------|
| **Pin 1** | VDD | Power Supply | **5V** (Critical: Must be 5V, not 3.3V) |
| **Pin 2** | RX | Receive Data | XIAO **D0** (UART TX - Pin P1.4) |
| **Pin 3** | TX | Transmit Data | XIAO **D1** (UART RX - Pin P1.5) |
| **Pin 4** | SEL | Interface Select | **Leave floating or GND** (for UART mode) |
| **Pin 5** | GND | Ground | **GND** |

### Critical Hardware Notes

⚠️ **POWER REQUIREMENTS:**
- The SPS30 **requires 5V power supply**
- It will NOT work reliably on 3.3V
- Current consumption: 60mA average, 80mA peak
- Make sure your 5V supply can provide sufficient current

⚠️ **INTERFACE SELECTION (Pin 4 - SEL):**
- **UART mode**: Leave floating OR connect to GND
- **I2C mode**: Connect to VDD (5V)
- For this project, we're using UART mode

⚠️ **TX/RX WIRING:**
- SPS30 TX → Board RX (D1)
- SPS30 RX → Board TX (D0)
- Cross-connection is required!

⚠️ **FAN OPERATION:**
- When powered correctly, you should hear/feel the fan spinning
- If the fan doesn't spin, check your 5V power supply

---

## Communication Protocol

### UART Settings
- **Baud Rate**: 115200
- **Data Bits**: 8
- **Parity**: None
- **Stop Bits**: 1
- **Flow Control**: None

### SHDLC Protocol Frame Structure

```
[0x7E] [ADDR] [CMD] [LEN] [DATA...] [CHK] [0x7E]
```

- **0x7E**: Start/Stop byte (frame delimiter)
- **ADDR**: Device address (0x00 for SPS30)
- **CMD**: Command byte
- **LEN**: Length of DATA field
- **DATA**: Command-specific data
- **CHK**: Checksum (inverted sum of ADDR+CMD+LEN+DATA)
- **0x7E**: Stop byte

---

## Key Commands

### 1. Wake-Up Command
```c
uint8_t wake_cmd = 0xFF;  // Single byte, no frame
```
- Send before any other command if sensor was in sleep mode
- Wait 50ms after sending

### 2. Start Measurement
```c
// Command: 0x00, Mode: 0x01 (floating point), Submode: 0x03
uint8_t start_cmd[] = {0x7E, 0x00, 0x00, 0x02, 0x01, 0x03, 0xF9, 0x7E};
```
- **0x01**: Floating point output format
- **0x03**: Submode (standard measurement)
- Wait 2 seconds for sensor to stabilize

### 3. Read Measured Values
```c
// Command: 0x03, No data
uint8_t read_cmd[] = {0x7E, 0x00, 0x03, 0x00, 0xFC, 0x7E};
```
- Returns 40 bytes of measurement data
- Values are in IEEE 754 floating-point format (big-endian)

### 4. Stop Measurement
```c
uint8_t stop_cmd[] = {0x7E, 0x00, 0x01, 0x00, 0xFE, 0x7E};
```

---

## Measurement Data Format

### Response Frame Structure
```
[0x7E] [ADDR] [CMD] [STATE] [LEN] [DATA0-39] [CHK] [0x7E]
```

### Data Layout (40 bytes, all IEEE 754 float, big-endian)

| Offset | Parameter | Unit | Description |
|--------|-----------|------|-------------|
| 0-3 | PM1.0 | µg/m³ | Mass concentration PM1.0 |
| 4-7 | PM2.5 | µg/m³ | Mass concentration PM2.5 |
| 8-11 | PM4.0 | µg/m³ | Mass concentration PM4.0 |
| 12-15 | PM10 | µg/m³ | Mass concentration PM10 |
| 16-19 | NC0.5 | #/cm³ | Number concentration 0.5µm |
| 20-23 | NC1.0 | #/cm³ | Number concentration 1.0µm |
| 24-27 | NC2.5 | #/cm³ | Number concentration 2.5µm |
| 28-31 | NC4.0 | #/cm³ | Number concentration 4.0µm |
| 32-35 | NC10 | #/cm³ | Number concentration 10µm |
| 36-39 | Typical Particle Size | µm | Typical particle size |

### PM2.5 Extraction
In the full frame, PM2.5 is located at:
- **Frame bytes 15-18** (DATA offset 10-13)
- Extract 4 bytes and convert from big-endian IEEE 754 float

---

## Software Implementation

### Current Configuration

Your project is already configured with:

1. **UART21** on pins D0/D1 at 115200 baud
2. **Proper SHDLC frame parsing** with checksum validation
3. **IEEE 754 float conversion** for measurement values
4. **Combined BME680 + SPS30** sensor reading

### Code Flow

```c
1. Initialize UART
2. Send wake-up command (0xFF)
3. Wait 50ms
4. Send start measurement command
5. Wait 2 seconds for stabilization
6. Loop:
   a. Send read command
   b. Wait 50ms
   c. Read response frame
   d. Parse PM2.5 value
   e. Display results
   f. Wait 2 seconds
```

---

## Troubleshooting

### No UART Response

**Check:**
1. ✅ Is SPS30 powered with **5V** (not 3.3V)?
2. ✅ Is the fan spinning? (You should hear it)
3. ✅ Is Pin 4 (SEL) **floating or connected to GND**?
4. ✅ Are TX/RX wires **crossed correctly**?
   - SPS30 TX → Board RX (D1)
   - SPS30 RX → Board TX (D0)
5. ✅ Is the UART baud rate **115200**?

### Fan Not Spinning

**Causes:**
- Insufficient 5V power supply
- Faulty power connection
- Defective sensor

**Solution:**
- Verify 5V supply with multimeter
- Check current capability (need 80mA peak)
- Try different power source

### PM2.5 Reads Zero

**Causes:**
- Sensor needs warm-up time (30 seconds)
- Clean air environment
- Sensor not in measurement mode

**Solution:**
- Wait 30-60 seconds after start
- Test in environment with particles (e.g., near cooking, dust)
- Verify start measurement command was sent

### Invalid Frame / Checksum Errors

**Causes:**
- Electrical noise on UART lines
- Incorrect baud rate
- Timing issues

**Solution:**
- Add pull-up resistors on TX/RX lines (4.7kΩ)
- Verify baud rate is exactly 115200
- Increase delays between commands

---

## Testing Procedure

### Step 1: Verify Hardware
```
1. Connect SPS30 as per pin diagram
2. Power on - fan should spin immediately
3. Measure voltage at Pin 1 - should be 5V ±0.25V
```

### Step 2: Build and Flash
```bash
cd c:\Users\geniu\sps30_matter_sensor
west build -b xiao_nrf54l15/nrf54l15/cpuapp
west flash
```

### Step 3: Monitor Output
```bash
# Open serial monitor at 115200 baud
# You should see:
=== BME680 + SPS30 Sensor Reader ===

BME680 initialized
Sending SPS30 wake-up...
Sending SPS30 start measurement...
SPS30 initialized
Monitoring UART for any incoming bytes...

[UART Frame (47 bytes): 7E 00 03 00 28 ...] Temp: 23.45°C  |  Hum: 45.67%  |  PM2.5: 12.34 µg/m³
```

### Step 4: Validate Readings

**PM2.5 Typical Values:**
- **0-12 µg/m³**: Good air quality
- **12-35 µg/m³**: Moderate
- **35-55 µg/m³**: Unhealthy for sensitive groups
- **55+ µg/m³**: Unhealthy

**Test by:**
- Blowing gently near sensor (should increase)
- Moving to different rooms
- Testing near cooking/dust sources

---

## Advanced Features

### Sleep Mode
To save power, you can put the sensor to sleep:
```c
uint8_t sleep_cmd[] = {0x7E, 0x00, 0x10, 0x00, 0xEF, 0x7E};
```
Wake it up with `0xFF` before next measurement.

### Fan Cleaning
The sensor has automatic fan cleaning. To trigger manually:
```c
uint8_t clean_cmd[] = {0x7E, 0x00, 0x56, 0x00, 0xA9, 0x7E};
```
This takes 10 seconds.

### Read Device Info
```c
uint8_t info_cmd[] = {0x7E, 0x00, 0xD0, 0x01, 0x00, 0x2E, 0x7E};
```
Returns serial number and product type.

---

## References

- [SPS30 Datasheet](https://sensirion.com/products/catalog/SPS30)
- [GitHub: embedded-uart-sps30](https://github.com/Sensirion/embedded-uart-sps30)
- [SHDLC Protocol Specification](https://github.com/Sensirion/embedded-uart-common)

---

## Summary Checklist

- [ ] SPS30 powered with **5V**
- [ ] Pin 4 (SEL) **floating or GND**
- [ ] TX/RX wires **crossed correctly**
- [ ] UART configured at **115200 baud**
- [ ] Fan **spinning** when powered
- [ ] Code sends **wake-up** command
- [ ] Code sends **start measurement** command
- [ ] Wait **2 seconds** for stabilization
- [ ] Parse response with **proper frame structure**
- [ ] Convert PM2.5 from **IEEE 754 float**

Good luck! 🎉
