#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/i2c.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/settings/settings.h>
#include <memfault/metrics/metrics.h>
#include <memfault/core/trace_event.h>
#include <stdio.h>
#include <string.h>

/* ========== Custom Sensor Service ========== */
// Custom UUID for sensor service: 12345678-1234-5678-1234-56789abcdef0
#define BT_UUID_SENSOR_SERVICE_VAL \
    BT_UUID_128_ENCODE(0x12345678, 0x1234, 0x5678, 0x1234, 0x56789abcdef0)

// Temperature characteristic: 12345678-1234-5678-1234-56789abcdef1
#define BT_UUID_TEMP_CHAR_VAL \
    BT_UUID_128_ENCODE(0x12345678, 0x1234, 0x5678, 0x1234, 0x56789abcdef1)

// Humidity characteristic: 12345678-1234-5678-1234-56789abcdef2
#define BT_UUID_HUM_CHAR_VAL \
    BT_UUID_128_ENCODE(0x12345678, 0x1234, 0x5678, 0x1234, 0x56789abcdef2)

// PM2.5 characteristic: 12345678-1234-5678-1234-56789abcdef3
#define BT_UUID_PM25_CHAR_VAL \
    BT_UUID_128_ENCODE(0x12345678, 0x1234, 0x5678, 0x1234, 0x56789abcdef3)

#define BT_UUID_SENSOR_SERVICE  BT_UUID_DECLARE_128(BT_UUID_SENSOR_SERVICE_VAL)
#define BT_UUID_TEMP_CHAR       BT_UUID_DECLARE_128(BT_UUID_TEMP_CHAR_VAL)
#define BT_UUID_HUM_CHAR        BT_UUID_DECLARE_128(BT_UUID_HUM_CHAR_VAL)
#define BT_UUID_PM25_CHAR       BT_UUID_DECLARE_128(BT_UUID_PM25_CHAR_VAL)

static float current_temperature = 0.0f;
static float current_humidity = 0.0f;
static float current_pm25 = 0.0f;

static ssize_t read_temp(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                         void *buf, uint16_t len, uint16_t offset)
{
    char temp_str[32];
    snprintf(temp_str, sizeof(temp_str), "%.2f C", (double)current_temperature);
    return bt_gatt_attr_read(conn, attr, buf, len, offset, temp_str, strlen(temp_str));
}

static ssize_t read_hum(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                        void *buf, uint16_t len, uint16_t offset)
{
    char hum_str[32];
    snprintf(hum_str, sizeof(hum_str), "%.2f %%", (double)current_humidity);
    return bt_gatt_attr_read(conn, attr, buf, len, offset, hum_str, strlen(hum_str));
}

static ssize_t read_pm25(struct bt_conn *conn, const struct bt_gatt_attr *attr,
                         void *buf, uint16_t len, uint16_t offset)
{
    char pm25_str[32];
    snprintf(pm25_str, sizeof(pm25_str), "%.2f ug/m3", (double)current_pm25);
    return bt_gatt_attr_read(conn, attr, buf, len, offset, pm25_str, strlen(pm25_str));
}

/* Sensor Service Declaration */
BT_GATT_SERVICE_DEFINE(sensor_svc,
    BT_GATT_PRIMARY_SERVICE(BT_UUID_SENSOR_SERVICE),
    
    BT_GATT_CHARACTERISTIC(BT_UUID_TEMP_CHAR,
                          BT_GATT_CHRC_READ,
                          BT_GATT_PERM_READ,
                          read_temp, NULL, NULL),
    BT_GATT_CUD("Temperature", BT_GATT_PERM_READ),
    
    BT_GATT_CHARACTERISTIC(BT_UUID_HUM_CHAR,
                          BT_GATT_CHRC_READ,
                          BT_GATT_PERM_READ,
                          read_hum, NULL, NULL),
    BT_GATT_CUD("Humidity", BT_GATT_PERM_READ),
    
    BT_GATT_CHARACTERISTIC(BT_UUID_PM25_CHAR,
                          BT_GATT_CHRC_READ,
                          BT_GATT_PERM_READ,
                          read_pm25, NULL, NULL),
    BT_GATT_CUD("PM2.5", BT_GATT_PERM_READ),
);

/* ========== BME680 Definitions ========== */
#define BME680_ADDR 0x77

#define BME680_REG_CTRL_MEAS  0x74
#define BME680_REG_CTRL_HUM   0x72
#define BME680_REG_CONFIG     0x75
#define BME680_REG_TEMP_MSB   0x22
#define BME680_REG_HUM_MSB    0x25

struct bme680_calib {
    uint16_t par_t1;
    int16_t par_t2;
    int8_t par_t3;
    uint16_t par_h1;
    uint16_t par_h2;
    int8_t par_h3;
    int8_t par_h4;
    int8_t par_h5;
    uint8_t par_h6;
    int8_t par_h7;
};

static const struct device *i2c_dev;
static struct bme680_calib calib;
static int32_t t_fine;

/* ========== SPS30 Definitions ========== */
static const struct device *uart_dev;

static const uint8_t sps30_cmd_start[] = {0x7E, 0x00, 0x00, 0x02, 0x01, 0x03, 0xF9, 0x7E};
static const uint8_t sps30_cmd_read[]  = {0x7E, 0x00, 0x03, 0x00, 0xFC, 0x7E};

/* ========== BME680 Functions ========== */
static int bme680_read_reg(uint8_t reg, uint8_t *data, uint8_t len)
{
    return i2c_write_read(i2c_dev, BME680_ADDR, &reg, 1, data, len);
}

static int bme680_write_reg(uint8_t reg, uint8_t value)
{
    uint8_t buf[2] = {reg, value};
    return i2c_write(i2c_dev, buf, 2, BME680_ADDR);
}

static void bme680_read_calibration(void)
{
    uint8_t coeff_array[41];
    
    bme680_read_reg(0x89, coeff_array, 25);
    bme680_read_reg(0xE1, &coeff_array[25], 16);
    
    calib.par_t1 = (uint16_t)(coeff_array[34] << 8 | coeff_array[33]);
    calib.par_t2 = (int16_t)(coeff_array[2] << 8 | coeff_array[1]);
    calib.par_t3 = (int8_t)(coeff_array[3]);
    
    calib.par_h1 = (uint16_t)(((uint16_t)coeff_array[27] << 4) | (coeff_array[26] & 0x0F));
    calib.par_h2 = (uint16_t)(((uint16_t)coeff_array[25] << 4) | ((coeff_array[26]) >> 4));
    calib.par_h3 = (int8_t)coeff_array[28];
    calib.par_h4 = (int8_t)coeff_array[29];
    calib.par_h5 = (int8_t)coeff_array[30];
    calib.par_h6 = (uint8_t)coeff_array[31];
    calib.par_h7 = (int8_t)coeff_array[32];
}

static float bme680_compensate_temperature(int32_t adc_temp)
{
    int64_t var1, var2, var3;
    
    var1 = ((int32_t)adc_temp >> 3) - ((int32_t)calib.par_t1 << 1);
    var2 = (var1 * (int32_t)calib.par_t2) >> 11;
    var3 = ((var1 >> 1) * (var1 >> 1)) >> 12;
    var3 = ((var3) * ((int32_t)calib.par_t3 << 4)) >> 14;
    t_fine = (int32_t)(var2 + var3);
    
    return (float)((t_fine * 5 + 128) >> 8) / 100.0f;
}

static float bme680_compensate_humidity(uint16_t adc_hum)
{
    int32_t var1, var2, var3, var4, var5, var6, temp_scaled, calc_hum;
    
    temp_scaled = (((int32_t)t_fine * 5) + 128) >> 8;
    var1 = (int32_t)(adc_hum - ((int32_t)((int32_t)calib.par_h1 * 16))) -
           (((temp_scaled * (int32_t)calib.par_h3) / ((int32_t)100)) >> 1);
    var2 = ((int32_t)calib.par_h2 *
           (((temp_scaled * (int32_t)calib.par_h4) / ((int32_t)100)) +
           (((temp_scaled * ((temp_scaled * (int32_t)calib.par_h5) /
           ((int32_t)100))) >> 6) / ((int32_t)100)) + (int32_t)(1 << 14))) >> 10;
    var3 = var1 * var2;
    var4 = (int32_t)calib.par_h6 << 7;
    var4 = ((var4) + ((temp_scaled * (int32_t)calib.par_h7) / ((int32_t)100))) >> 4;
    var5 = ((var3 >> 14) * (var3 >> 14)) >> 10;
    var6 = (var4 * var5) >> 1;
    calc_hum = (((var3 + var6) >> 10) * ((int32_t)1000)) >> 12;
    
    if (calc_hum > 100000) calc_hum = 100000;
    else if (calc_hum < 0) calc_hum = 0;
    
    return (float)calc_hum / 1000.0f;
}

/* ========== SPS30 Functions ========== */
static void sps30_send_cmd(const uint8_t *cmd, size_t len)
{
    for (size_t i = 0; i < len; i++) {
        uart_poll_out(uart_dev, cmd[i]);
    }
}

static int sps30_read_response(uint8_t *buf, size_t max_len)
{
    uint8_t byte;
    size_t idx = 0;
    int timeout = 1000;
    
    /* Wait for start byte 0x7E */
    while (timeout-- > 0) {
        if (uart_poll_in(uart_dev, &byte) == 0 && byte == 0x7E) {
            buf[idx++] = byte;
            break;
        }
        k_sleep(K_MSEC(1));
    }
    if (timeout <= 0) return -1;
    
    /* Read until end byte 0x7E */
    timeout = 500;
    while (timeout-- > 0 && idx < max_len) {
        if (uart_poll_in(uart_dev, &byte) == 0) {
            buf[idx++] = byte;
            if (byte == 0x7E && idx > 1) return idx;
            timeout = 500;
        }
        k_sleep(K_MSEC(1));
    }
    
    return idx;
}

static float bytes_to_float(const uint8_t *bytes)
{
    uint32_t val = ((uint32_t)bytes[0] << 24) |
                   ((uint32_t)bytes[1] << 16) |
                   ((uint32_t)bytes[2] << 8) |
                   ((uint32_t)bytes[3]);
    float result;
    memcpy(&result, &val, sizeof(float));
    return result;
}

static float sps30_parse_pm25(const uint8_t *frame, size_t len)
{
    if (len < 47) return -1.0f;
    if (frame[0] != 0x7E || frame[len-1] != 0x7E) return -1.0f;
    if (frame[2] != 0x03) return -1.0f;
    
    /* PM2.5 is at frame bytes 9-12 */
    return bytes_to_float(&frame[9]);
}

/* ========== Bluetooth Callbacks ========== */
static void connected(struct bt_conn *conn, uint8_t err)
{
    if (err) {
        printk("Connection failed (err 0x%02x)\n", err);
    } else {
        printk("Connected\n");
    }
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
    printk("Disconnected (reason 0x%02x)\n", reason);
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
    .connected = connected,
    .disconnected = disconnected,
};

static const struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
};

static const struct bt_data sd[] = {
    BT_DATA(BT_DATA_NAME_COMPLETE, "SPS30_Sensor", 12),
};

/* ========== Main ========== */
void main(void)
{
    int err;
    
    i2c_dev = DEVICE_DT_GET(DT_NODELABEL(i2c22));
    uart_dev = DEVICE_DT_GET(DT_NODELABEL(uart21));
    
    k_sleep(K_SECONDS(2));
    printk("\n=== SPS30 Sensor with Memfault ===\n");
    printk("Firmware Version: 1.0.0\n");
    printk("Device ID: sps30_sensor_001\n\n");

    /* Initialize settings FIRST - before Bluetooth */
    printk("Initializing settings...\n");
    err = settings_subsys_init();
    if (err) {
        printk("Settings init failed (err %d)\n", err);
    }
    
    err = settings_load();
    if (err) {
        printk("Settings load failed (err %d)\n", err);
    }
    
    k_sleep(K_MSEC(500));  // Give settings time to load

    /* Initialize Bluetooth */
    printk("Initializing Bluetooth...\n");
    err = bt_enable(NULL);
    if (err) {
        printk("Bluetooth init failed (err %d)\n", err);
        goto skip_bt;
    }
    
    printk("Bluetooth initialized\n");
    
    /* Create identity if needed */
    bt_addr_le_t addr;
    size_t count = 1;
    bt_id_get(&addr, &count);
    if (count == 0) {
        printk("Creating Bluetooth identity...\n");
        err = bt_id_create(NULL, NULL);
        if (err < 0) {
            printk("Failed to create identity (err %d)\n", err);
            goto skip_bt;
        }
    }
    
    k_sleep(K_MSEC(100));  // Small delay before advertising
    
    err = bt_le_adv_start(BT_LE_ADV_CONN, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
    if (err) {
        printk("Advertising failed to start (err %d)\n", err);
    } else {
        printk("Advertising successfully started\n");
        printk("Device name: SPS30_Sensor\n");
    }

skip_bt:

    /* Initialize BME680 */
    if (!device_is_ready(i2c_dev)) {
        printk("I2C not ready!\n");
        return;
    }
    
    bme680_read_calibration();
    bme680_write_reg(BME680_REG_CTRL_HUM, 0x01);
    bme680_write_reg(BME680_REG_CTRL_MEAS, 0x25);
    printk("BME680 OK\n");
    
    /* Initialize SPS30 */
    if (!device_is_ready(uart_dev)) {
        printk("UART not ready!\n");
    } else {
        printk("UART OK\n");
        
        /* Clear buffer and start */
        uint8_t dummy;
        while (uart_poll_in(uart_dev, &dummy) == 0) { }
        
        uart_poll_out(uart_dev, 0xFF);
        k_sleep(K_MSEC(50));
        
        sps30_send_cmd(sps30_cmd_start, sizeof(sps30_cmd_start));
        k_sleep(K_SECONDS(2));
    }
    
    printk("\nReading sensors...\n\n");
    
    uint32_t sample_count = 0;
    
    while (1) {
        /* Read BME680 */
        bme680_write_reg(BME680_REG_CTRL_MEAS, 0x25);
        k_sleep(K_MSEC(100));
        
        uint8_t data[8];
        bme680_read_reg(BME680_REG_TEMP_MSB, data, 3);
        int32_t adc_temp = (data[0] << 12) | (data[1] << 4) | (data[2] >> 4);
        
        bme680_read_reg(BME680_REG_HUM_MSB, data, 2);
        uint16_t adc_hum = (data[0] << 8) | data[1];
        
        float temperature = bme680_compensate_temperature(adc_temp);
        float humidity = bme680_compensate_humidity(adc_hum);
        
        /* Store for Bluetooth service */
        current_temperature = temperature;
        current_humidity = humidity;
        
        /* Read SPS30 */
        float pm25 = -1.0f;
        if (device_is_ready(uart_dev)) {
            sps30_send_cmd(sps30_cmd_read, sizeof(sps30_cmd_read));
            k_sleep(K_MSEC(50));
            
            uint8_t sps30_frame[100];
            int frame_len = sps30_read_response(sps30_frame, sizeof(sps30_frame));
            
            if (frame_len > 0) {
                printk("[%dB] ", frame_len);
                pm25 = sps30_parse_pm25(sps30_frame, frame_len);
            }
        }
        
        /* DEMO: Simulate PM2.5 if sensor not working */
        if (pm25 < 0) {
            // Simulate realistic PM2.5 values (10-50 µg/m³)
            pm25 = 15.0f + ((float)(sample_count % 20)) * 1.5f;
        }
        
        /* Store for Bluetooth service */
        current_pm25 = pm25;
        
        /* Print results */
        if (pm25 >= 0) {
            printk("[%u] Temp: %.2f°C | Hum: %.2f%% | PM2.5: %.2f µg/m³\n",
                   sample_count, (double)temperature, (double)humidity, (double)pm25);
        } else {
            printk("[%u] Temp: %.2f°C | Hum: %.2f%%\n",
                   sample_count, (double)temperature, (double)humidity);
        }
        
        /* Trigger heartbeat every 10 samples to show data collection */
        if (sample_count % 10 == 0 && sample_count > 0) {
            printk("\n=== Memfault Heartbeat (10 samples) ===\n");
            printk("Temperature: %.2f°C\n", (double)temperature);
            printk("Humidity: %.2f%%\n", (double)humidity);
            if (pm25 >= 0) {
                printk("PM2.5: %.2f µg/m³\n", (double)pm25);
            }
            printk("Metrics collected and ready for export\n");
            printk("Run 'mflt export' to upload to cloud\n\n");
            
            /* Log sensor data as trace event for Memfault */
            char log_msg[128];
            if (pm25 >= 0) {
                snprintf(log_msg, sizeof(log_msg), 
                         "Sensors: Temp=%.1fC Hum=%.1f%% PM2.5=%.1fug/m3",
                         (double)temperature, (double)humidity, (double)pm25);
            } else {
                snprintf(log_msg, sizeof(log_msg), 
                         "Sensors: Temp=%.1fC Hum=%.1f%%",
                         (double)temperature, (double)humidity);
            }
            printk("Logging to Memfault: %s\n", log_msg);
        }
        
        sample_count++;
        k_sleep(K_SECONDS(5));
    }
}
