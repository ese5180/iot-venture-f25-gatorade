# Memfault Integration Guide

## Overview

This project now includes **Memfault (nRF Cloud)** integration for fleet management with:

✅ **OTA Firmware Updates** with version tracking  
✅ **Core Dump** for crash reporting  
✅ **Custom Metrics** forwarding temperature, humidity, and PM2.5 data  
✅ **Bluetooth connectivity** for wireless updates  
✅ **MCUBoot bootloader** for safe firmware updates  

---

## Setup Steps

### 1. Create nRF Cloud Account

1. Go to [nrfcloud.com](https://nrfcloud.com)
2. Create an account or sign in
3. Create a new project

### 2. Get Your Project Key

1. In nRF Cloud, go to **Settings → General**
2. Copy your **Memfault Project Key**
3. Open `prj.conf` and update this line:
   ```conf
   CONFIG_MEMFAULT_NCS_PROJECT_KEY="YOUR_KEY_HERE"
   ```

### 3. Build with Sysbuild

The project now requires **sysbuild** to include the MCUBoot bootloader:

```bash
west build -b xiao_nrf54l15/nrf54l15/cpuapp --sysbuild
west flash
```

Or in VS Code nRF Connect extension:
- Enable "Sysbuild" in build configuration
- Build and flash

### 4. Connect via Bluetooth

1. Install **nRF Connect Device Manager** app on your phone:
   - [iOS](https://apps.apple.com/app/nrf-device-manager/id1519423539)
   - [Android](https://play.google.com/store/apps/details?id=no.nordicsemi.android.nrfconnectdevicemanager)

2. Open the app and scan for "SPS30_Sensor"

3. Connect to the device

4. The device will automatically sync data to nRF Cloud

---

## Features Implemented

### 1. OTA Firmware Updates ✅

**How it works:**
- Device advertises via Bluetooth
- MCUBoot bootloader manages firmware updates
- Version info tracked: `1.0.0` (update in `prj.conf`)

**To test:**
1. Change version in `prj.conf`:
   ```conf
   CONFIG_MEMFAULT_NCS_FW_VERSION="1.0.1"
   CONFIG_BT_DIS_FW_REV_STR="1.0.1"
   CONFIG_MCUBOOT_IMGTOOL_SIGN_VERSION="1.0.1"
   ```

2. Rebuild with sysbuild

3. In nRF Cloud:
   - Go to **Firmware Updates**
   - Upload the new `.bin` file from `build/zephyr/app_update.bin`
   - Create a release
   - Activate the release

4. Device will receive update via Bluetooth

### 2. Core Dump / Crash Reporting ✅

**How it works:**
- Memfault automatically captures crashes
- Stack traces sent to cloud
- View in nRF Cloud dashboard

**To test a crash:**
```bash
# Connect via serial terminal
# Type in shell:
mflt test assert
```

This will trigger a crash and send coredump to Memfault.

### 3. Custom Metrics ✅

**Metrics being forwarded:**
- `temperature_c` - Temperature in Celsius (signed integer)
- `humidity_pct` - Humidity percentage (unsigned integer)
- `pm25_ugm3` - PM2.5 concentration in µg/m³ (unsigned integer)

**How it works:**
- Metrics updated every 5 seconds
- Heartbeat sent every 10 samples
- Data synced to nRF Cloud when connected via Bluetooth

**View metrics:**
1. Go to nRF Cloud dashboard
2. Select your device
3. View **Metrics** tab
4. See temperature, humidity, and PM2.5 trends

### 4. Trace Events ✅

**Events logged:**
- `bluetooth_connected` - When BLE connects
- `bluetooth_disconnected` - When BLE disconnects
- `sensor_heartbeat` - Every 10 samples
- `i2c_init_failed` - If BME680 fails
- `uart_init_failed` - If SPS30 UART fails

---

## Shell Commands

The device includes a shell for testing. Connect via serial terminal (115200 baud):

### Memfault Commands

```bash
# Get device info
mflt get_device_info

# Trigger test crash
mflt test assert

# Print current metrics
mflt get_core

# Export data
mflt export

# Post data to cloud (requires BLE connection)
mflt post_chunks
```

### General Commands

```bash
# List all commands
help

# Get kernel version
kernel version

# Reboot device
kernel reboot cold
```

---

## Monitoring in nRF Cloud

### Device Dashboard

1. **Overview**: See device status, last seen, firmware version
2. **Metrics**: View temperature, humidity, PM2.5 trends over time
3. **Traces**: See events (connections, heartbeats, errors)
4. **Issues**: View crashes and coredumps
5. **Firmware**: Manage OTA updates

### Alerts

You can set up alerts for:
- Temperature out of range
- Humidity extremes
- High PM2.5 levels
- Device offline

---

## File Structure

```
sps30_matter_sensor/
├── src/
│   └── main.c              # Main application with Memfault integration
├── boards/
│   ├── app.overlay         # Pin configuration
│   └── xiao_nrf54l15.overlay
├── prj.conf                # Project configuration with Memfault
├── sysbuild.conf           # Sysbuild config for MCUBoot
└── CMakeLists.txt
```

---

## Troubleshooting

### Build Errors

**Error: "sysbuild not found"**
- Make sure you're using `--sysbuild` flag
- Or enable sysbuild in VS Code nRF Connect extension

**Error: "MEMFAULT_NCS_PROJECT_KEY is empty"**
- Update `prj.conf` with your actual project key from nRF Cloud

### Connection Issues

**Device not advertising:**
- Check serial output for "Advertising successfully started"
- Make sure Bluetooth is enabled in `prj.conf`

**Can't connect via nRF Device Manager:**
- Make sure device is advertising
- Try restarting the app
- Check device is in range

### Data Not Appearing in Cloud

**Metrics not showing:**
- Connect device via Bluetooth
- Data syncs when connected
- Check "Last Seen" timestamp in dashboard

**Crashes not reported:**
- Trigger test crash: `mflt test assert`
- Connect via Bluetooth to upload coredump
- Check "Issues" tab in dashboard

---

## Extra Credit Features

### Implemented:
✅ **Custom Metrics** - Temperature, humidity, PM2.5  
✅ **Trace Events** - Connection events, heartbeats, errors  
✅ **Shell Commands** - For testing and debugging  

### Possible Additions:
- **A/B Testing**: Deploy different firmware versions to different devices
- **Staged Rollout**: Gradual firmware deployment (10% → 50% → 100%)
- **Battery Tracking**: Add battery voltage metric
- **Geolocation**: Add GPS coordinates if available

---

## Demo Checklist

For your IoT Venture demonstration:

- [ ] Device advertising via Bluetooth
- [ ] Connect via nRF Device Manager app
- [ ] Show firmware version in app (1.0.0)
- [ ] Show temperature and humidity readings
- [ ] Trigger test crash and show coredump in cloud
- [ ] Show metrics dashboard with sensor data
- [ ] Demonstrate OTA update to version 1.0.1
- [ ] Show updated version after OTA

---

## Resources

- [nRF Cloud Documentation](https://docs.nordicsemi.com/bundle/nrf-cloud/page/index.html)
- [Memfault Docs](https://docs.memfault.com/)
- [nRF Connect Device Manager](https://www.nordicsemi.com/Products/Development-tools/nrf-connect-device-manager)
- [MCUBoot Documentation](https://docs.mcuboot.com/)

---

**Note**: Since your SPS30 sensor isn't working yet (fan not spinning), the PM2.5 metric will show as 0 or not update. The temperature and humidity from BME680 will work fine and demonstrate the Memfault integration.

Good luck with your demo! 🚀
