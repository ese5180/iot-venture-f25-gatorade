/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

#include <kernel.h>
#include <net/conn_mgr_connectivity.h>
#include <memfault/metrics/metrics.h>
#include <memfault/ports/zephyr/http.h>
#include <memfault/core/data_packetizer.h>
#include <dk_buttons_and_leds.h>
#include <logging/log.h>
#include <net/wifi_credentials.h>
#include <net/wifi_mgmt.h>
#include <net/net_if.h>
#include <net/net_ip.h>
#include <net/fota_download.h>
#include <sys/reboot.h>
#include <memfault/http/http_client.h>
#include <memfault/core/device_info.h>

LOG_MODULE_REGISTER(memfault_wifi_example, CONFIG_MEMFAULT_SAMPLE_LOG_LEVEL);

/* Network connection semaphore */
static K_SEM_DEFINE(nw_connected_sem, 0, 1);

/* Event callback structures */
static struct net_mgmt_event_callback l4_cb;
static struct net_mgmt_event_callback conn_cb;
static struct net_mgmt_event_callback wifi_cb;

/* Define the work for rebooting */
static struct k_work_delayable reboot_work;

/* Forward declaration for button handler */
static void check_for_fota_updates(void);

/* FOTA download handler */
static void fota_dl_handler(const struct fota_download_evt *evt)
{
    switch (evt->id) {
    case FOTA_DOWNLOAD_EVT_PROGRESS:
        LOG_INF("FOTA download progress: %d%%", evt->progress);
        break;
    case FOTA_DOWNLOAD_EVT_ERROR:
        LOG_ERR("FOTA download error");
        break;
    case FOTA_DOWNLOAD_EVT_FINISHED:
        LOG_INF("FOTA download finished, reboot needed");
        /* Schedule a reboot after 5 seconds */
        k_work_schedule(&reboot_work, K_SECONDS(5));
        break;
    default:
        break;
    }
}

/* Memfault OTA handler implementation */
static int memfault_ota_handler(const char *download_url, size_t url_len) {
    int err;
    
    LOG_INF("Initiating FOTA download from URL (len %d)", url_len);
    
    /* Initialize the FOTA handler */
    err = fota_download_init(fota_dl_handler);
    if (err) {
        LOG_ERR("Failed to initialize FOTA download client: %d", err);
        return err;
    }
    
    /* Start the FOTA download using the full URL
     * Parameters: host (full URL), file (NULL for full URL), sec_tag, pdn_id, fragment_size 
     * Note: pdn_id is 0 (default), not NULL */
    err = fota_download_start(download_url, NULL, 0, 0, 0);
    if (err) {
        LOG_ERR("Failed to start FOTA download: %d", err);
        return err;
    }
    
    LOG_INF("FOTA download started");
    return 0;
}

/* Button handler */
static void button_handler(uint32_t button_states, uint32_t has_changed)
{
    if ((has_changed & DK_BTN1_MSK) && (button_states & DK_BTN1_MSK)) {
        LOG_INF("Button 1 pressed - sending Memfault data");
        memfault_metrics_heartbeat_debug_trigger();
        memfault_zephyr_port_post_data();
    } else if ((has_changed & DK_BTN2_MSK) && (button_states & DK_BTN2_MSK)) {
        LOG_INF("Button 2 pressed - checking for FOTA updates");
        check_for_fota_updates();
    }
}

/* L4 connection handler */
static void l4_event_handler(struct net_mgmt_event_callback *cb, uint32_t event,
                 struct net_if *iface)
{
    if (event == NET_EVENT_L4_CONNECTED) {
        LOG_INF("Network connectivity established");
        k_sem_give(&nw_connected_sem);
    } else if (event == NET_EVENT_L4_DISCONNECTED) {
        LOG_INF("Network connectivity lost");
    }
}

/* WiFi event handler */
static void wifi_mgmt_event_handler(struct net_mgmt_event_callback *cb,
                                   uint32_t mgmt_event,
                                   struct net_if *iface)
{
    switch (mgmt_event) {
    case NET_EVENT_WIFI_CONNECT_RESULT:
        LOG_INF("WiFi connection established");
        break;
    case NET_EVENT_WIFI_DISCONNECT_RESULT:
        LOG_WRN("WiFi disconnected");
        break;
    }
}

/* Fatal error handler */
static void connectivity_event_handler(struct net_mgmt_event_callback *cb, 
                                      uint32_t event, struct net_if *iface)
{
    if (event == NET_EVENT_CONN_IF_FATAL_ERROR) {
        LOG_ERR("Fatal connection manager error");
    }
}

/* Connect to WiFi */
static int connect_wifi(void)
{
    struct net_if *iface = net_if_get_default();
    
    static struct wifi_connect_req_params cnx_params = {
        .ssid = CONFIG_WIFI_CREDENTIALS_STATIC_SSID,
        .ssid_length = sizeof(CONFIG_WIFI_CREDENTIALS_STATIC_SSID) - 1,
        .psk = CONFIG_WIFI_CREDENTIALS_STATIC_PASSWORD,
        .psk_length = sizeof(CONFIG_WIFI_CREDENTIALS_STATIC_PASSWORD) - 1,
        .channel = WIFI_CHANNEL_ANY,
        .security = WIFI_SECURITY_TYPE_PSK,
    };
    
    LOG_INF("Connecting to WiFi: %s", CONFIG_WIFI_CREDENTIALS_STATIC_SSID);
    
    int ret = net_mgmt(NET_REQUEST_WIFI_CONNECT, iface, &cnx_params,
                      sizeof(struct wifi_connect_req_params));
    
    if (ret) {
        LOG_ERR("WiFi connection request failed: %d", ret);
    } else {
        LOG_INF("WiFi connection request sent");
    }

    return ret;
}

/* Function to check WiFi connectivity */
static bool is_wifi_connected(void)
{
    struct net_if *iface = net_if_get_default();
    return net_if_is_up(iface);
}

/* Work handler for rebooting */
static void reboot_work_handler(struct k_work *work)
{
    LOG_INF("Rebooting system to apply update");
    sys_reboot(SYS_REBOOT_COLD);
}

static void check_for_fota_updates(void)
{
    int err;
    static const sMemfaultOtaUpdateHandler memfault_ota_handler_impl = {
        .handle_data = memfault_ota_handler,
    };
    
    LOG_INF("Checking for FOTA updates from Memfault...");
    
    /* Use Memfault's helper function to start the FOTA download with our handler */
    err = memfault_zephyr_port_ota_update(&memfault_ota_handler_impl);
    if (err) {
        LOG_ERR("Failed to start FOTA download from Memfault: %d", err);
    } else {
        LOG_INF("FOTA download from Memfault initiated");
    }
}

/* Main function - Fixed return type to int */
int main(void)
{
    int err;
    
    LOG_INF("nRF7002 Memfault FOTA example started");
    
    /* Initialize buttons */
    err = dk_buttons_init(button_handler);
    if (err) {
        LOG_ERR("Failed to initialize buttons: %d", err);
    }
    
    /* Initialize LED */
    err = dk_leds_init();
    if (err) {
        LOG_ERR("Failed to initialize LEDs: %d", err);
    }
    
    /* Register event handlers */
    net_mgmt_init_event_callback(&l4_cb, l4_event_handler, 
                               NET_EVENT_L4_CONNECTED | NET_EVENT_L4_DISCONNECTED);
    net_mgmt_add_event_callback(&l4_cb);
    
    net_mgmt_init_event_callback(&wifi_cb, wifi_mgmt_event_handler,
                               NET_EVENT_WIFI_CONNECT_RESULT | 
                               NET_EVENT_WIFI_DISCONNECT_RESULT);
    net_mgmt_add_event_callback(&wifi_cb);
    
    net_mgmt_init_event_callback(&conn_cb, connectivity_event_handler,
                               NET_EVENT_CONN_IF_FATAL_ERROR);
    net_mgmt_add_event_callback(&conn_cb);
    
    /* Initialize the reboot work handler */
    k_work_init_delayable(&reboot_work, reboot_work_handler);
    
    /* Connect to WiFi */
    err = connect_wifi();
    if (err) {
        LOG_ERR("Failed to connect to WiFi: %d", err);
        return err;
    }
    
    /* Initialize Memfault */
    memfault_zephyr_port_install_root_certs();
    
    /* Wait for network connection */
    LOG_INF("Waiting for network connection...");
    err = k_sem_take(&nw_connected_sem, K_SECONDS(30));
    if (err) {
        LOG_WRN("Network connection timeout, continuing anyway...");
    }
    
    /* Wait a bit more for stable connection */
    k_sleep(K_SECONDS(2));
    
    /* Check for Memfault FOTA updates */
    check_for_fota_updates();
    
    /* Main loop */
    while (1) {
        k_sleep(K_SECONDS(60));
        
        /* Send Memfault data periodically */
        memfault_zephyr_port_post_data();
        
        /* Check WiFi connection status and reconnect if needed */
        if (!is_wifi_connected()) {
            LOG_WRN("WiFi disconnected, reconnecting...");
            connect_wifi();
        }
    }
    
    return 0;
}