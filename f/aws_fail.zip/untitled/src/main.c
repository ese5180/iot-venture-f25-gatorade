#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <net/aws_fota.h>
#include <net/mqtt.h>

LOG_MODULE_REGISTER(aws_fota_app, LOG_LEVEL_INF);

static void aws_fota_callback(struct aws_fota_event *fota_evt)
{
        switch (fota_evt->id) {
        case AWS_FOTA_EVT_START:
                LOG_INF("AWS FOTA: start");
                break;
        case AWS_FOTA_EVT_DONE:
                LOG_INF("AWS FOTA: done");
                /* The application should reboot to run the new image here */
                break;
        case AWS_FOTA_EVT_ERROR:
                LOG_ERR("AWS FOTA: error %d", fota_evt->err);
                break;
        case AWS_FOTA_EVT_ERASE_PENDING:
                LOG_INF("AWS FOTA: erase pending");
                break;
        case AWS_FOTA_EVT_ERASE_DONE:
                LOG_INF("AWS FOTA: erase done");
                break;
        case AWS_FOTA_EVT_DL_PROGRESS:
                LOG_INF("AWS FOTA: downloaded %u/%u", fota_evt->dl.progress.offset, fota_evt->dl.progress.total);
                break;
        default:
                LOG_WRN("AWS FOTA: unknown event %d", fota_evt->id);
                break;
        }
}

int main(void)
{
        int ret;

        LOG_INF("Starting AWS FOTA sample (nRF7002) - initializing...");

        ret = aws_fota_init(aws_fota_callback);
        if (ret) {
                LOG_ERR("aws_fota_init failed: %d", ret);
                return ret;
        }

        LOG_INF("aws_fota initialized (waiting for job)");

        return 0;
}

#if defined(CONFIG_MQTT_LIB)
int aws_fota_mqtt_forward(struct mqtt_client *const client, const struct mqtt_evt *evt)
{

        return aws_fota_mqtt_evt_handler(client, evt);
}
#endif
