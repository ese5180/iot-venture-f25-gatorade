# AWS IoT FOTA sample for nRF7002DK

This project shows how to enable AWS IoT FOTA (aws_fota) on the nRF7002DK.

What I changed:
- Enabled `CONFIG_AWS_FOTA` and dependencies in `prj.conf`.
- Added a minimal `main.c` that initializes the `aws_fota` library and logs events.

Notes and next steps:
- This sample only initializes the AWS FOTA library. You must add network and
  MQTT connectivity to communicate with AWS IoT Core and receive Job notifications.
- Configure MQTT credentials and TLS (MBEDTLS) properly. Set the security tag
  `CONFIG_AWS_FOTA_DOWNLOAD_SECURITY_TAG` to the tag where you have stored TLS
  credentials (client cert and private key) if using HTTPS downloads.
- Upload your FOTA image (`app_update.bin`) to an S3 bucket and create an AWS IoT
  job that points to the file. See Nordic documentation for job document format.

Build and flash:
1. Install nRF Connect SDK and toolchain (west, zephyr, etc.)
2. Build for the nRF7002DK: 
```
west build -b nrf7002dk_nrf5340dk
west flash
```

References:
- https://developer.nordicsemi.com/nRF_Connect_SDK/doc/latest/nrf/libraries/networking/aws_fota.html
- https://docs.aws.amazon.com/iot/latest/developerguide/iot-jobs.html
