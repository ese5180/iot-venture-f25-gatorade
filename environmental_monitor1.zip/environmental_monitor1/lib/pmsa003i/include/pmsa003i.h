#ifndef PMSA003I_H
#define PMSA003I_H

#include <stdint.h>


/**
 * @brief Structure to hold sensor data
 */
struct pmsa003i_data {
    uint16_t pm1_0;
    uint16_t pm2_5;
    uint16_t pm10_0;
};

/**
 * @brief Initialize the PMSA003I sensor
 * @return 0 on success, negative errno on failure
 */
int pmsa003i_init(void);

/**
 * @brief Read data from the sensor
 * @param data Pointer to data structure to populate
 * @return 0 on success, negative errno on failure
 */
int pmsa003i_read_data(struct pmsa003i_data *data);

#endif
