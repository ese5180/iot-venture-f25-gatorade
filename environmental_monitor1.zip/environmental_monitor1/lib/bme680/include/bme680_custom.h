#ifndef BME680_CUSTOM_H
#define BME680_CUSTOM_H

#include <stdint.h>

/**
 * @brief Structure to hold BME680 sensor data
 */
struct bme680_custom_data {
    int32_t temperature; // 0.01 degC
    uint32_t humidity;   // 0.001 %RH
    uint32_t pressure;   // Pascal
    uint32_t gas_res;    // Ohms
};

/**
 * @brief Initialize the BME680 sensor
 * @return 0 on success, negative errno on failure
 */
int bme680_custom_init(void);

/**
 * @brief Read data from the sensor
 * @param data Pointer to data structure
 * @return 0 on success, negative errno on failure
 */
int bme680_custom_read(struct bme680_custom_data *data);

#endif
