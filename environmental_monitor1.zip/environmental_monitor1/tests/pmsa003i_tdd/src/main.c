#include <zephyr/ztest.h>
#include "pmsa003i.h"

ZTEST(pmsa003i_tests, test_init_and_read)
{
    // 1. Test Initialization
    int ret = pmsa003i_init();
    zassert_equal(ret, 0, "Initialization failed");

    // 2. Test Read
    struct pmsa003i_data data;
    ret = pmsa003i_read_data(&data);
    zassert_equal(ret, 0, "Read failed");
    
    // Verify some dummy logic
    zassert_true(data.pm2_5 >= 0, "PM2.5 cannot be negative");
}

ZTEST_SUITE(pmsa003i_tests, NULL, NULL, NULL, NULL, NULL);
