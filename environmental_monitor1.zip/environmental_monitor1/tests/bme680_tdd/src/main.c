#include <zephyr/ztest.h>

// Driver header (Missing in Red Phase)
#include "bme680_custom.h" 

ZTEST(bme680_tests, test_init_and_read)
{
    // 1. Initialization
    int ret = bme680_custom_init();
    zassert_equal(ret, 0, "BME680 Init failed");

    // 2. Read
    struct bme680_custom_data data;
    ret = bme680_custom_read(&data);
    zassert_equal(ret, 0, "BME680 Read failed");

    // 3. Validation
    zassert_true(data.temperature >= -4000 && data.temperature <= 8500, "Temp out of range");
    zassert_true(data.humidity >= 0 && data.humidity <= 100000, "Humidity out of range");
}

ZTEST_SUITE(bme680_tests, NULL, NULL, NULL, NULL, NULL);
