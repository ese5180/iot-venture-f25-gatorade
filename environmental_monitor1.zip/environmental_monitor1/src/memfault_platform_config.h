#pragma once

// Memfault Platform Configuration

// Point to our custom metric definitions
#define MEMFAULT_METRICS_USER_HEARTBEAT_DEFS_FILE \
    "memfault_metrics_heartbeat_config.def"

// Point to our custom trace event definitions  
#define MEMFAULT_TRACE_REASON_USER_DEFS_FILE \
    "memfault_trace_reason_user_config.def"

// Project key
#define MEMFAULT_PROJECT_KEY "Qvi3o2sZUDwakk62XNrnfcK4H6OfXvVw"

// Enable coredump collection
#define MEMFAULT_COREDUMP_COLLECT_LOG_REGIONS 1
#define MEMFAULT_COREDUMP_COLLECT_BSS_REGIONS 1
#define MEMFAULT_COREDUMP_COLLECT_DATA_REGIONS 1